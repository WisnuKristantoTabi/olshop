<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\ProdukModel;

class Dashboard extends Controller
{
	protected $produk;

	function __construct()
	{
		$this->produk = new ProdukModel();
	}
    public function index()
	{
		
		$data['produks'] = $this->produk
		->orderBy('created_at', 'desc')
		->findAll(3);

		return view('home/index', $data);
	}

	public function shop()
	{
		
		$data['produks'] = $this->produk
		->orderBy('created_at', 'desc')
		->findAll(3);

		return view('home/shop', $data);
	}

}