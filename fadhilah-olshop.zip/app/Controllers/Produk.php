<?php

namespace App\Controllers;
use Illuminate\Http\Request;
use App\Models\ProdukModel;

class Produk extends BaseController
{
  protected $produk;

	function __construct()
	{
		$this->produk = new ProdukModel();
	}

    public function index()
    {
      // $data['produks'] = $this->produk->findAll();
      $data = [
        'title_meta' => view('partials/title-meta', ['title' => 'Produk']),
        'page_title' => view('partials/page-title', ['title' => 'Produk', 'li_1' => 'Produk', 'li_2' => 'Tabel Produk']),
        'produks'     => $this->produk->findAll()
      ];
		  return view('apps/produk', $data);
    }

    public function create()
	  {
      
      // $this->contact->insert([
          //     'name' => $this->request->getPost('name'),
          //     'email' => $this->request->getPost('email'),
          //     'phone' => $this->request->getPost('phone'),
          //     'address' => $this->request->getPost('address'),
          // ]);
          $data = [
            'title_meta' => view('partials/title-meta', ['title' => 'Bootstrap_Basic']),
            'page_title' => view('partials/page-title', ['title' => 'Bootstrap_Basic', 'li_1' => 'Tables', 'li_2' => 'Bootstrap Basic'])
          ];

      return view('apps/tambah-produk', $data);
	  }

    public function save()
    {
        $dataBerkas = $this->request->getFile('file');
        $fileName = $dataBerkas->getRandomName();
        

        $this->produk->insert([
          'nama_produk' => "tes",
          'ukuran' => 'test',
          'deskripsi' => 'test',
          'harga' => 'test',
          'status' => 'test',
          'keterangan'=> 'test',
          'gambar' => $fileName
        ]);

        $dataBerkas->move('assets/dashboard/images/', $fileName);
        // return redirect()->to(base_url('tambah-produk'));
          echo $dataBerkas;
    }
}
