<!doctype html>
<html lang="en">

<head>

    <?= $title_meta ?>

    <!-- dropzone css -->
    <link href="assets/libs/dropzone/min/dropzone.min.css" rel="stylesheet" type="text/css" />

    <?= $this->include('partials/head-css') ?>

</head>

<?= $this->include('partials/body') ?>

<!-- <body data-layout="horizontal"> -->

<!-- Begin page -->
<div id="layout-wrapper">

    <?= $this->include('partials/menu') ?>

    <!-- ============================================================== -->
    <!-- Start right Content here -->
    <!-- ============================================================== -->
    <div class="main-content">

        <div class="page-content">
            <div class="container-fluid">

                <!-- start page title -->
                <?= $page_title ?>
                <!-- end page title -->
            <div class="card">
            
            
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Textual inputs</h4>
                                <p class="card-title-desc">Here are examples of <code>.form-control</code> applied to each
                                    textual HTML5 <code>&lt;input&gt;</code> <code>type</code>.</p>
                            </div>
                            <div class="card-body p-4">
                            
                                <div class="row">
                                        <div>
                                            <div class="mb-3">
                                                <label for="example-text-input" class="form-label">Text</label>
                                                <input class="form-control" type="text" value="Artisanal kale" id="example-text-input">
                                            </div>
                                            <div class="mb-3">
                                                <label for="example-search-input" class="form-label">Search</label>
                                                <input class="form-control" type="search" value="How do I shoot web" id="example-search-input">
                                            </div>
                                            <div class="mb-3">
                                                <label for="example-email-input" class="form-label">Email</label>
                                                <input class="form-control" type="email" value="bootstrap@example.com" id="example-email-input">
                                            </div>
                                            <div class="mb-3">
                                                <label for="example-url-input" class="form-label">URL</label>
                                                <input class="form-control" type="url" value="https://getbootstrap.com" id="example-url-input">
                                            </div>
                                            <div class="mb-3">
                                                <label for="example-tel-input" class="form-label">Telephone</label>
                                                <input class="form-control" type="tel" value="1-(555)-555-5555" id="example-tel-input">
                                            </div>
                                            <div class="mb-3">
                                                <label for="example-password-input" class="form-label">Password</label>
                                                <input class="form-control" type="password" value="hunter2" id="example-password-input">
                                            </div>
                                            <div class="mb-3">
                                                <label for="example-number-input" class="form-label">Number</label>
                                                <input class="form-control" type="number" value="42" id="example-number-input">
                                            </div>
                                            <div>
                                                <label for="example-datetime-local-input" class="form-label">Date and time</label>
                                                <input class="form-control" type="datetime-local" value="2019-08-19T13:45:00" id="example-datetime-local-input">
                                            </div>
                                    </div>
                                </div>
                              
                            </div>
                        </div>
                    </div> <!-- end col -->
                </div>
                <!-- end row -->
            <div class="card-body p-4">
                            
            <div class="row">
            <div>
            <form action="<?php echo base_url('produk-save'); ?>" enctype="multipart&#x2F;form-data" method="post" accept-charset="utf-8">
            <input type="file" name="file" value=""  />
            <input type="submit" name="mysubmit" value="Upload File!"  />
            </form>
            </div>
            </div>
                                                </div>
            </div> 
            </div> <!-- container-fluid -->
        </div>
        <!-- End Page-content -->


        <?= $this->include('partials/footer') ?>
    </div>
    <!-- end main content-->

</div>
<!-- END layout-wrapper -->


<?= $this->include('partials/right-sidebar') ?>

<!-- JAVASCRIPT -->
<?= $this->include('partials/vendor-scripts') ?>

<!-- dropzone js -->
<script src="assets/libs/dropzone/min/dropzone.min.js"></script>

<script src="assets/js/app.js"></script>

</body>

</html>