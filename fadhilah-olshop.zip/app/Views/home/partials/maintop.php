 <!-- Start Main Top -->
 <div class="main-top">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    <div class="text-slid-box">
                        <div id="offer-box" class="carouselTicker">
                            <ul class="offer-box">
                                <li>
                                    <i class="fab fa-opencart"></i> Iklan Promo 1
                                </li>
                                <li>
                                    <i class="fab fa-opencart"></i> Iklan Promo 2
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    <div class="custom-select-box">
                    <a href="<?php echo base_url('auth-login'); ?>" class="btn hvr-hover">Login</a>
                    </div>
                    <div class="right-phone-box">
                        <p>whatsapp :- <a href="#">082347502225</a></p>
                    </div>
                    <div class="our-link">
                        <ul>
                            <li><a href="#">Temukan Kami</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Main Top -->